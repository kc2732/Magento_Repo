<?php
class Magebird_Popup_Block_Examplee extends Mage_Core_Block_Template
{
  function testiram(){
    echo 1;
  }       
}