<?php


/**
 * This class should be thrown when unexpected data is found in the database.
 */
class InvalidDatabaseException2 extends Exception
{
}
